******************************************************************************

               Frin : An Improved Version of the Cass Algorithm

******************************************************************************

Frin is an implementation in Java of the algorithm of Hongyan
and Wang Juan. 
Frin takes as input a set of rooted phylogenetic trees given in Newick format. 
As output, the program provides the user with a rooted phylogenetic networks in 
dot format, which can be opened by Graphviz (for more details about dot format and Graphviz,
see http://www.graphviz.org/). 


The program can be started by using the following command:

----------------------------------------------
./Frin.jar --p percent --input infile --output outfile
----------------------------------------------

where percent is the percent threshold of clusters for network construction(such as 0.2).



******************************************************************************


**************************************************************************
CONTACT      
**************************************************************************
Please send bug reports and technical questions to Hongyan at 
<fzhongyan1@163.com>.